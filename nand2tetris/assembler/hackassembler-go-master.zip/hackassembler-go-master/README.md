# gopath e goroot


export GOPATH=$HOME/dev/go


# run
 go run . ~/apps/nand2tetris/projects/06/add/Add.asm 